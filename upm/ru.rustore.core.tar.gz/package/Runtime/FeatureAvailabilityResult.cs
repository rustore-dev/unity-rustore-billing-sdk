namespace RuStore {

    public class FeatureAvailabilityResult {

        public bool isAvailable;
        public RuStoreError cause;
    }
}
