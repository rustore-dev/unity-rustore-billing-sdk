## История изменений

### Release 6.1.1
- Версия SDK billing 6.1.0.
- Исправлен парсинг поля sandbox в PaymentResult.


### Release 6.1.0
- Версия SDK billing 6.1.0.


### Release 6.0.0
- Версия SDK billing 6.+.
- Добавлено поле sandbox у моделей результата покупки PaymentResult.
- Убрано поле description у модели Purchase.
- Изменена структура репозитория.
- Добавлен проект с исходным кодом .aar пакетов.
- RuStoreSDK помещена в отдельную assembly.


### Release 5.0.3
- Исправлены зависимости SDK.


### Release 5.0.2
- Исправлен метод CheckPurchasesAvailability.


### Release 5.0.1
- Исправлен метод CheckPurchasesAvailability.


### Release 5.0.0
- Версия SDK billing 5.+.


### Release 3.1.0
- Версия SDK billing 3.1.0.


### Release 2.2.1
- Исправлены зависимости SDK.


### Release 2.2.0
- Версия SDK billing 2.2.0.
