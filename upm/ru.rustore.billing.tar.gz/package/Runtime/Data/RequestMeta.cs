namespace RuStore.BillingClient {

    public class RequestMeta {

        public string traceId;
    }
}
