namespace RuStore.BillingClient {

    public enum BillingClientTheme {

        Dark,
        Light,
    }
}
