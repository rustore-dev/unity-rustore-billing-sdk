namespace RuStore.BillingClient {

    public class SubscriptionPeriod {

        public int years;
        public int months;
        public int days;
    }
}
