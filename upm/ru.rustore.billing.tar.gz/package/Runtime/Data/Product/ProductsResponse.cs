using System.Collections.Generic;

namespace RuStore.BillingClient {

    public class ProductsResponse : ResponseWithCode {

        public List<Product> products;
    }
}
