namespace RuStore.BillingClient {

    public class DigitalShopGeneralError {

        public string name;
        public int code;
        public string description;
    }
}
