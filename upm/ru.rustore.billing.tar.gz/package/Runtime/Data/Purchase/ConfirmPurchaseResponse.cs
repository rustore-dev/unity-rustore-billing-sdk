using System.Collections.Generic;

namespace RuStore.BillingClient {

    public class ConfirmPurchaseResponse : ResponseWithCode {
    }
}
