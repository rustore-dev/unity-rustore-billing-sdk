using System.Collections.Generic;

namespace RuStore.BillingClient {

    public class DeletePurchaseResponse : ResponseWithCode {
    }
}
