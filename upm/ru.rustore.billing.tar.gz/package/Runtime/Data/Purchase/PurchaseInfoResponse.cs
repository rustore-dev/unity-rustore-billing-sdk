using System.Collections.Generic;

namespace RuStore.BillingClient {

    public class PurchaseInfoResponse : ResponseWithCode {

        public Purchase purchase;
    }
}
